# Crypto Listing Radar MVP v1.0.0
Professional Android MVVM crypto listing alert application.

Features: AI Listing Analyzer, Watchlist, History, Notifications, Material 3 Dark Crypto UI.
