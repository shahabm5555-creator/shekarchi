# Crypto Listing Radar

Crypto Listing Radar is an Android MVP for monitoring cryptocurrency listing announcements.

## Stack
Kotlin, Jetpack Compose, Material 3, MVVM-ready Repository architecture, Room, Retrofit, Coroutines, WorkManager and Firebase Messaging dependency.

## Build
Open the project in Android Studio and run:
`./gradlew assembleDebug`

The GitHub Actions workflow builds the debug APK and uploads it as an artifact.

## Notes
The exchange provider layer is intentionally prepared for real APIs. The included worker uses demo text so the app can demonstrate the analyzer and notification flow without API keys.

No login is required.
