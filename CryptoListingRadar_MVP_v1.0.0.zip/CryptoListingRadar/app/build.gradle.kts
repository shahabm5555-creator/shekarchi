plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }

android { namespace="com.crypto.radar"; compileSdk=35
 defaultConfig { applicationId="com.crypto.radar"; minSdk=26; targetSdk=35; versionCode=1; versionName="1.0.0" }
 buildFeatures { compose=true }
}

dependencies {
 implementation("androidx.core:core-ktx:1.13.1")
 implementation("androidx.activity:activity-compose:1.9.2")
 implementation("androidx.compose.material3:material3:1.3.0")
 implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
 implementation("androidx.room:room-runtime:2.6.1")
 implementation("com.squareup.retrofit2:retrofit:2.11.0")
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
 implementation("androidx.work:work-runtime-ktx:2.9.1")
 implementation("com.google.firebase:firebase-messaging:25.0.0")
}
