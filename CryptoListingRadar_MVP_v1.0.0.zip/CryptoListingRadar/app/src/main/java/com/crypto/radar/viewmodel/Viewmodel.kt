package com.crypto.radar.viewmodel
class Viewmodel {}
