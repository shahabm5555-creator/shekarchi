package com.crypto.radar.data.database
class Database {}
