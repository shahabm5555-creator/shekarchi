package com.crypto.radar.notification
class Notification {}
