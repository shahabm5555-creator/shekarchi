package com.crypto.radar.data.remote
class Remote {}
