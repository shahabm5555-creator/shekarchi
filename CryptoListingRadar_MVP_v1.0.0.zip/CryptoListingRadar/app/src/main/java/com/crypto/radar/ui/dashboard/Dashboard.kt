package com.crypto.radar.ui.dashboard
class Dashboard {}
