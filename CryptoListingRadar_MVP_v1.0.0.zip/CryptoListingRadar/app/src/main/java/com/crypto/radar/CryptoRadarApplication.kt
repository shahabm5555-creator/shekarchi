package com.crypto.radar
import android.app.Application
class CryptoRadarApplication: Application()
