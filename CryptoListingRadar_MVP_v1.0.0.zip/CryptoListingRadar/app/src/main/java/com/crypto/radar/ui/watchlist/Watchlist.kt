package com.crypto.radar.ui.watchlist
class Watchlist {}
