package com.crypto.radar.ui.settings
class Settings {}
