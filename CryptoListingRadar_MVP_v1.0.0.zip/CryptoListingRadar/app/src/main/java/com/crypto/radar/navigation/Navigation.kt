package com.crypto.radar.navigation
class Navigation {}
