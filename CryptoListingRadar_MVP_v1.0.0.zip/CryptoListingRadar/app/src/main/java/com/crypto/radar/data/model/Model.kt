package com.crypto.radar.data.model
class Model {}
