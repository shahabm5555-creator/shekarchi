package com.crypto.radar.ai
class AIListingAnalyzer{
 private val keys=listOf("will list","listing announcement","new token listing","spot listing","trading starts","available for trading")
 fun analyze(text:String): Result = Result(keys.count{text.lowercase().contains(it)}*15)
 data class Result(val confidence:Int){val status=if(confidence>70)"Detected" else "Unknown"}
}
