package com.crypto.radar.ui.alerts
class Alerts {}
