package com.crypto.radar.ui.details
class Details {}
