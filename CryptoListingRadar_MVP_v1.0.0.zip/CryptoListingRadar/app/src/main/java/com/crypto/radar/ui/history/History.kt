package com.crypto.radar.ui.history
class History {}
