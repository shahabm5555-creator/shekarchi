@echo off
echo Gradle wrapper placeholder. Generate official wrapper with gradle wrapper.
