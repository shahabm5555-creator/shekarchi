package com.crypto.radar.ui.dashboard

import androidx.compose.runtime.Composable
import androidx.compose.material3.Text
import com.crypto.radar.ui.components.GlassCard

@Composable
fun DashboardScreen(){
    GlassCard {
        Text("🤖 Crypto AI Radar")
        Text("🚀 New Listing Detection")
        Text("AI Confidence: 98%")
    }
}
