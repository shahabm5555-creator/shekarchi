package com.crypto.radar.data.model

data class CryptoListing(
    val coinName: String,
    val symbol: String,
    val exchange: String,
    val status: String,
    val confidence: Int,
    val source: String
)
