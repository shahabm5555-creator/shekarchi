# Crypto Listing Radar

Android Kotlin + Jetpack Compose crypto listing alert app.

Current scaffold:
- MVVM structure
- Compose UI
- Glass style dashboard
- Listing model

Next steps:
- Add API integrations
- Add Firebase notifications
- Add AI analyzer backend
