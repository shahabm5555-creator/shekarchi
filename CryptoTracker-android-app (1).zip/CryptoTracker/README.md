# Crypto Tracker (Volume Surge + Upcoming Listings)

A Kotlin + Jetpack Compose Android app with two screens:

1. **Volume Surge** — top coins by 24h trading-volume increase (real data, CoinGecko).
2. **Upcoming Listings** — upcoming CEX listing announcements (mocked, ready to swap for a real feed — see below).

Dark Material 3 UI, bottom navigation, MVVM + light Clean Architecture (data / domain-ish repository layer / ui), Retrofit + Gson, Coroutines + Flow, Coil for images.

---

## 1. Project structure

```
CryptoTracker/
├── build.gradle.kts                 # root build script
├── settings.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── app/
│   ├── build.gradle.kts             # app module deps (Compose, Retrofit, Coil, Nav...)
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── res/
│       │   ├── values/strings.xml, themes.xml, ic_launcher_background.xml
│       │   ├── drawable/ic_launcher_foreground.xml
│       │   └── mipmap-anydpi-v26/ic_launcher.xml, ic_launcher_round.xml
│       └── java/com/example/cryptotracker/
│           ├── MainActivity.kt
│           ├── di/ServiceLocator.kt                 # manual DI (swap for Hilt if desired)
│           ├── data/
│           │   ├── model/
│           │   │   ├── Coin.kt                      # VolumeSurgeCoin (UI-facing model)
│           │   │   └── Listing.kt                   # Listing + ListingStatus
│           │   ├── remote/
│           │   │   ├── CoinGeckoApiService.kt        # Retrofit interface (markets + chart)
│           │   │   ├── RetrofitInstance.kt           # Retrofit/OkHttp singleton
│           │   │   └── dto/
│           │   │       ├── CoinMarketDto.kt
│           │   │       └── MarketChartDto.kt
│           │   └── repository/
│           │       ├── CoinRepository.kt             # real volume-surge calculation
│           │       └── ListingRepository.kt          # mock + real-API swap notes
│           └── ui/
│               ├── theme/Color.kt, Type.kt, Theme.kt
│               ├── navigation/BottomNavItem.kt, NavGraph.kt
│               ├── components/
│               │   ├── VolumeSurgeCoinItem.kt
│               │   ├── ListingItem.kt
│               │   └── StateComposables.kt           # loading/error states
│               └── screens/
│                   ├── volumesurge/VolumeSurgeScreen.kt, VolumeSurgeViewModel.kt
│                   └── listings/ListingsScreen.kt, ListingsViewModel.kt
```

---

## 2. Dependencies (already wired in `app/build.gradle.kts`)

- Jetpack Compose BOM `2024.06.00`, Material 3, Material Icons Extended
- `androidx.navigation:navigation-compose:2.7.7`
- `retrofit2` + `converter-gson` + `okhttp` (+ logging interceptor)
- `kotlinx-coroutines-android`
- `io.coil-kt:coil-compose` for image loading
- Lifecycle ViewModel Compose

No API keys are required to run the app out of the box (CoinGecko's public endpoints are key-less; listings are mocked locally).

---

## 3. How the two screens get their data

### Screen 1 — Volume Surge (real APIs: CoinGecko + Binance, no key needed)
Shows coins ranked **#1–#1000 by market cap** whose real trading **capital on Binance specifically** (not aggregated across exchanges) has grown the fastest over the last 24h. Implemented in `CoinRepositoryImpl`:

1. `CoinGeckoApiService.getCoinMarkets(order = "market_cap_desc")` is paged (4 calls × 250/page) to get the current top-1000-by-market-cap universe.
2. `BinanceApiService.getAll24hrTickers()` — **one call** — returns live 24h stats for every symbol traded on Binance.
3. Coins are matched to Binance by `SYMBOL + "USDT"` and kept only if both in the top-1000 market-cap list *and* actually listed on Binance.
4. Matches are ranked by Binance's `quoteVolume` (the actual USDT value traded — real "money", not coin count) and the top `candidatePoolSize` (default 40) current-largest are kept as candidates.
5. For each candidate, `BinanceApiService.getKlines(interval = "1h", limit = 48)` pulls 48 hourly candles; summing the **quote-asset-volume** field (index 7 of each candle — again, money, not coin count) for the last 24 candles vs. the previous 24 gives a real 24h-over-24h capital-inflow percentage.
6. Coins below `minSurgePercent` (default 15%) are dropped; the rest are ranked by that surge %.

Step 5 is bounded to `candidatePoolSize` coins (not all ~1000) to keep the number of API calls reasonable for a mobile client — see section 4 for how to move this to a backend job if you want the full 1000 checked every refresh.

### Screen 2 — Upcoming Listings (currently mocked, real-API-ready)
There is no single free, key-less public API that tracks "upcoming CEX listing announcements" the way CoinGecko covers market data. `MockListingRepositoryImpl` (in `ListingRepository.kt`) ships 6 realistic sample entries so the screen is fully functional immediately. The `ListingRepository` interface and `ListingsViewModel` don't know or care whether the data is mocked or real — see section 4 for how to plug in a real source.

---

## 4. Connecting real-world data sources

### Volume Surge — going beyond the demo calculation
The current implementation already uses real Binance data (`ticker/24hr` + `klines`), but the per-candidate `klines` loop (bounded to `candidatePoolSize`, default 40) still means ~40 extra calls per refresh. For production:

- **Cover the full top-1000, not just the top-40 candidates** — move the klines fan-out to a backend job: a small cron/server polls Binance's `klines` for all ~1000 matched symbols on a schedule (e.g. hourly), stores the last two 24h volume sums per symbol (Firestore/Postgres/Redis), and exposes a single `/volume-surge` endpoint the app calls. This removes all per-coin fan-out from the client and lets you check every coin, not just the current top 40.
- **Other exchanges** — the same pattern (`ticker/24hr` + `klines`, or the exchange's equivalent) works for Bybit, KuCoin, OKX, etc. if you want multi-exchange capital-flow tracking instead of Binance-only.
- **CoinMarketCap Pro API** — the `/v1/cryptocurrency/listings/latest` endpoint returns a `volume_change_24h` field directly (aggregated across exchanges, not Binance-specific), if you want a simpler single-call approximation instead of exchange-specific tracking. Requires an API key (`CMC_PRO_API_KEY` header).
- Binance's `klines` endpoint has generous public rate limits (weight-based, ~1200/min), so the current bounded approach is safe to run from the client as-is; just watch the weight budget if you raise `candidatePoolSize` a lot.

To swap the implementation, only `CoinRepositoryImpl` needs to change — `CoinRepository` (the interface), `VolumeSurgeViewModel`, and the UI are untouched since they depend on the interface, not the concrete class.

### Upcoming Listings — going from mock to real
1. **CoinMarketCal API** (https://coinmarketcal.com/en/apidoc) — free tier available, has an `exchange-listing` event category. Sign up for an API key, add a `ListingApiService` Retrofit interface (a stub is sketched at the bottom of `ListingRepository.kt`), and add the key via `RetrofitInstance` or a `local.properties`-backed `BuildConfig` field (don't hardcode it).
2. **Exchange announcement feeds** — Binance, Coinbase, KuCoin, and Bybit all publish RSS/JSON feeds for their announcement sections. You can build a lightweight backend (Cloud Function, etc.) that polls these, tags posts mentioning "will list" / "New Listing", and exposes a normalized JSON endpoint for the app to consume — this avoids scraping HTML on-device and lets you keep a stable schema.
3. Once you have a real source, implement `RemoteListingRepositoryImpl : ListingRepository` and swap it in `ServiceLocator.kt`:
   ```kotlin
   val listingRepository: ListingRepository by lazy {
       RemoteListingRepositoryImpl(api = RetrofitInstance.listingApi, apiKey = BuildConfig.LISTING_API_KEY)
   }
   ```
   No other file needs to change.

---

## 5. Running the project

1. Open the `CryptoTracker/` folder in **Android Studio (Koala/2024.1+)**.
2. Let Android Studio sync Gradle — it will generate the Gradle wrapper JAR automatically on first sync (this project ships `gradle/wrapper/gradle-wrapper.properties` pointing at Gradle 8.7, but not the binary `gradle-wrapper.jar`, since that's a binary file; Android Studio creates it for you, or run `gradle wrapper` once if you have Gradle installed locally).
3. Run on an emulator or device with **API 24+**.
4. Internet permission is already declared; no configuration needed for the mocked/free endpoints.

---

## 6. Notes / possible next steps
- Add a Room cache layer so both screens survive offline/cold-start gracefully.
- Add pull-to-refresh (`androidx.compose.material.pullrefresh` or Accompanist SwipeRefresh) on both `LazyColumn`s — the ViewModels already expose `onRefresh()`.
- Move `ServiceLocator` to Hilt (`@HiltAndroidApp`, `@Inject` constructors) once the project grows past a couple of screens.
- Add unit tests for `CoinRepositoryImpl.computeVolumeSurge()` math and `ListingsViewModel` state transitions.
