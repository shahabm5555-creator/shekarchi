# Add project specific ProGuard rules here.
-keep class com.example.cryptotracker.data.remote.dto.** { *; }
-keep class com.example.cryptotracker.data.model.** { *; }
