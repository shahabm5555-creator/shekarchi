package com.example.cryptotracker.data.remote

import com.example.cryptotracker.data.remote.dto.BinanceTicker24hrDto
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Public (key-less) Binance Spot REST endpoints used to measure real
 * capital flow ON Binance specifically — separate from CoinGecko, which
 * aggregates volume across many exchanges.
 * Base URL: https://api.binance.com/
 */
interface BinanceApiService {

    /**
     * 24h rolling ticker stats for EVERY symbol traded on Binance, in a
     * single call. We pull this once per refresh and filter client-side
     * to the USDT pairs that match our market-cap-ranked coin list.
     */
    @GET("api/v3/ticker/24hr")
    suspend fun getAll24hrTickers(): List<BinanceTicker24hrDto>

    /**
     * Candlestick data for one symbol. We use this to compare the most
     * recent 24h of trading against the prior 24h, so we can compute a
     * real "volume/capital increase %" instead of just a current snapshot.
     * Index 7 of each candle array is "quote asset volume" (money, not
     * coin count) — that's the field we sum.
     *
     * Returns raw arrays per Binance's API shape:
     * [openTime, open, high, low, close, volume, closeTime,
     *  quoteAssetVolume, numTrades, takerBuyBase, takerBuyQuote, ignore]
     */
    @GET("api/v3/klines")
    suspend fun getKlines(
        @Query("symbol") symbol: String,
        @Query("interval") interval: String = "1h",
        @Query("limit") limit: Int = 48
    ): List<List<Any>>
}
