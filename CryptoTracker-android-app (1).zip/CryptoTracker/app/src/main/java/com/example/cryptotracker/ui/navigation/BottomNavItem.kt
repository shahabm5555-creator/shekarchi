package com.example.cryptotracker.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String) {
    data object VolumeSurge : Screen("volume_surge")
    data object UpcomingListings : Screen("upcoming_listings")
}

data class BottomNavItem(
    val screen: Screen,
    val label: String,
    val icon: ImageVector
)

val bottomNavItems = listOf(
    BottomNavItem(Screen.VolumeSurge, "Volume Surge", Icons.Filled.TrendingUp),
    BottomNavItem(Screen.UpcomingListings, "Listings", Icons.Filled.List)
)
