package com.example.cryptotracker.ui.screens.volumesurge

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cryptotracker.data.model.VolumeSurgeCoin
import com.example.cryptotracker.data.repository.CoinRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class VolumeSurgeUiState(
    val isLoading: Boolean = false,
    val coins: List<VolumeSurgeCoin> = emptyList(),
    val errorMessage: String? = null
)

class VolumeSurgeViewModel(
    private val repository: CoinRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(VolumeSurgeUiState(isLoading = true))
    val uiState: StateFlow<VolumeSurgeUiState> = _uiState.asStateFlow()

    init {
        loadVolumeSurgeCoins()
    }

    fun loadVolumeSurgeCoins() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }

            repository.getVolumeSurgeCoins()
                .onSuccess { coins ->
                    _uiState.update {
                        it.copy(isLoading = false, coins = coins, errorMessage = null)
                    }
                }
                .onFailure { throwable ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = throwable.message ?: "Failed to load market data"
                        )
                    }
                }
        }
    }

    fun onRefresh() = loadVolumeSurgeCoins()
}
