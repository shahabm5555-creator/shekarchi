package com.example.cryptotracker.data.remote

import com.example.cryptotracker.data.remote.dto.CoinMarketDto
import com.example.cryptotracker.data.remote.dto.MarketChartDto
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Free, key-less CoinGecko endpoints used for the "Volume Surge" screen.
 * Base URL: https://api.coingecko.com/api/v3/
 *
 * Rate limit on the free tier is low (~10-30 calls/min) — see README for
 * notes on upgrading to a Pro key or a different provider for production.
 */
interface CoinGeckoApiService {

    @GET("coins/markets")
    suspend fun getCoinMarkets(
        @Query("vs_currency") vsCurrency: String = "usd",
        @Query("order") order: String = "volume_desc",
        @Query("per_page") perPage: Int = 50,
        @Query("page") page: Int = 1,
        @Query("price_change_percentage") priceChangePercentage: String = "1h,24h",
        @Query("sparkline") sparkline: Boolean = false
    ): List<CoinMarketDto>

    @GET("coins/{id}/market_chart")
    suspend fun getMarketChart(
        @Path("id") coinId: String,
        @Query("vs_currency") vsCurrency: String = "usd",
        @Query("days") days: Int = 2,
        @Query("interval") interval: String = "hourly"
    ): MarketChartDto
}
