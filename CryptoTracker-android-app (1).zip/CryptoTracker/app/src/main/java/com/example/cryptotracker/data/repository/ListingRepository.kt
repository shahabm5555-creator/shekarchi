package com.example.cryptotracker.data.repository

import com.example.cryptotracker.data.model.Listing
import com.example.cryptotracker.data.model.ListingStatus
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit

interface ListingRepository {
    suspend fun getUpcomingListings(): Result<List<Listing>>
}

/**
 * There is no single, free, key-less public API that reliably tracks
 * "upcoming CEX listing announcements" the way CoinGecko covers market
 * data. In production this repository would call one of:
 *   - CoinMarketCal API (https://coinmarketcal.com/en/apidoc) — has a
 *     dedicated "exchange listing" event category, requires a free API key.
 *   - CryptoRank's "Listings" endpoint (paid).
 *   - Your own scraper/aggregator hitting each exchange's announcement
 *     blog (Binance, Coinbase, KuCoin, Bybit all publish RSS/JSON feeds
 *     for their announcement sections) feeding a backend you control.
 *
 * For this project, MockListingDataSource below stands in for that call so
 * the app is fully runnable out of the box. Swap `MockListingRepositoryImpl`
 * for `RemoteListingRepositoryImpl` (stubbed at the bottom of this file)
 * once you have an API key — the ViewModel and UI do not need to change,
 * since both implement the same [ListingRepository] contract.
 */
class MockListingRepositoryImpl : ListingRepository {

    override suspend fun getUpcomingListings(): Result<List<Listing>> = runCatching {
        // Simulate network latency so loading states are visible/testable.
        delay(600)
        MockListingDataSource.listings
    }
}

private object MockListingDataSource {
    private val now = System.currentTimeMillis()
    private fun hoursFromNow(hours: Long) = now + TimeUnit.HOURS.toMillis(hours)
    private fun daysFromNow(days: Long) = now + TimeUnit.DAYS.toMillis(days)

    val listings = listOf(
        Listing(
            id = "1",
            coinName = "Celestia",
            coinSymbol = "TIA",
            iconUrl = "https://assets.coingecko.com/coins/images/31967/large/tia.jpg",
            exchangeName = "Binance",
            exchangeLogoUrl = "https://assets.coingecko.com/markets/images/52/large/binance.jpg",
            listingDateTimeEpochMillis = hoursFromNow(6),
            status = ListingStatus.CONFIRMED,
            sourceUrl = "https://www.binance.com/en/support/announcement"
        ),
        Listing(
            id = "2",
            coinName = "Jupiter",
            coinSymbol = "JUP",
            iconUrl = "https://assets.coingecko.com/coins/images/34188/large/jup.png",
            exchangeName = "Coinbase",
            exchangeLogoUrl = "https://assets.coingecko.com/markets/images/23/large/Coinbase_Coin_Primary.png",
            listingDateTimeEpochMillis = daysFromNow(1),
            status = ListingStatus.CONFIRMED,
            sourceUrl = "https://www.coinbase.com/blog"
        ),
        Listing(
            id = "3",
            coinName = "Wormhole",
            coinSymbol = "W",
            iconUrl = "https://assets.coingecko.com/coins/images/35087/large/wormhole.png",
            exchangeName = "KuCoin",
            exchangeLogoUrl = "https://assets.coingecko.com/markets/images/61/large/kucoin.png",
            listingDateTimeEpochMillis = daysFromNow(2),
            status = ListingStatus.RUMORED,
            sourceUrl = "https://www.kucoin.com/announcement"
        ),
        Listing(
            id = "4",
            coinName = "Ethena",
            coinSymbol = "ENA",
            iconUrl = "https://assets.coingecko.com/coins/images/36530/large/ethena.png",
            exchangeName = "Bybit",
            exchangeLogoUrl = "https://assets.coingecko.com/markets/images/698/large/bybit_spot.png",
            listingDateTimeEpochMillis = daysFromNow(3),
            status = ListingStatus.CONFIRMED,
            sourceUrl = "https://announcements.bybit.com/"
        ),
        Listing(
            id = "5",
            coinName = "Pyth Network",
            coinSymbol = "PYTH",
            iconUrl = "https://assets.coingecko.com/coins/images/31924/large/pyth.png",
            exchangeName = "OKX",
            exchangeLogoUrl = "https://assets.coingecko.com/markets/images/96/large/okex.jpg",
            listingDateTimeEpochMillis = hoursFromNow(1),
            status = ListingStatus.LIVE,
            sourceUrl = "https://www.okx.com/help/section/announcements"
        ),
        Listing(
            id = "6",
            coinName = "Dogwifhat",
            coinSymbol = "WIF",
            iconUrl = "https://assets.coingecko.com/coins/images/33566/large/dogwifhat.jpg",
            exchangeName = "Binance",
            exchangeLogoUrl = "https://assets.coingecko.com/markets/images/52/large/binance.jpg",
            listingDateTimeEpochMillis = daysFromNow(5),
            status = ListingStatus.DELAYED,
            sourceUrl = "https://www.binance.com/en/support/announcement"
        )
    ).sortedBy { it.listingDateTimeEpochMillis }
}

// --- Real-API swap point ------------------------------------------------
// interface ListingApiService {
//     @GET("events")
//     suspend fun getExchangeListingEvents(
//         @Header("x-api-key") apiKey: String,
//         @Query("categories") categories: String = "exchange-listing"
//     ): CoinMarketCalResponseDto
// }
//
// class RemoteListingRepositoryImpl(
//     private val api: ListingApiService,
//     private val apiKey: String
// ) : ListingRepository {
//     override suspend fun getUpcomingListings(): Result<List<Listing>> = runCatching {
//         api.getExchangeListingEvents(apiKey).body.map { it.toListing() }
//     }
// }
