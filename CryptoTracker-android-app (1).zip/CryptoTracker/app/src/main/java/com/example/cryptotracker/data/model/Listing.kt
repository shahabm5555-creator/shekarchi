package com.example.cryptotracker.data.model

/**
 * Domain model used by Screen 2 (Upcoming Exchange Listings).
 */
data class Listing(
    val id: String,
    val coinName: String,
    val coinSymbol: String,
    val iconUrl: String,
    val exchangeName: String,
    val exchangeLogoUrl: String,
    val listingDateTimeEpochMillis: Long,
    val status: ListingStatus,
    val sourceUrl: String? = null
)

enum class ListingStatus(val label: String) {
    CONFIRMED("Confirmed"),
    RUMORED("Rumored"),
    LIVE("Live Now"),
    DELAYED("Delayed")
}
