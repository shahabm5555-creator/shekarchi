package com.example.cryptotracker.data.model

/**
 * Domain model used by Screen 1 (Volume Surge).
 * This is the UI-facing model — mapped from the network DTO in the repository layer,
 * so the UI never depends on raw API shapes.
 */
data class VolumeSurgeCoin(
    val rank: Int,
    val marketCapRank: Int,
    val id: String,
    val name: String,
    val symbol: String,
    val iconUrl: String,
    val currentPrice: Double,
    val priceChangePercent24h: Double,
    val volumeChangePercent24h: Double,
    val totalVolume24h: Double,
    val marketCap: Double
)
