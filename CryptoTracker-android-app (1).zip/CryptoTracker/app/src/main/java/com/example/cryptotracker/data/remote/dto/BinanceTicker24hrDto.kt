package com.example.cryptotracker.data.remote.dto

import com.google.gson.annotations.SerializedName

/**
 * Maps to a single entry of Binance's public `GET /api/v3/ticker/24hr`
 * (no API key needed, no auth). Binance returns numeric fields as JSON
 * strings, so they're parsed as String here and converted with
 * `.toDoubleOrNull()` where used.
 *
 * `quoteVolume` is the field that actually matters for "capital flow":
 * it's the 24h traded value denominated in the quote asset (USDT for the
 * pairs we use), i.e. real money volume — not just a coin count.
 *
 * Docs: https://binance-docs.github.io/apidocs/spot/en/#24hr-ticker-price-change-statistics
 */
data class BinanceTicker24hrDto(
    @SerializedName("symbol") val symbol: String,
    @SerializedName("priceChangePercent") val priceChangePercent: String?,
    @SerializedName("lastPrice") val lastPrice: String?,
    @SerializedName("volume") val volume: String?,
    @SerializedName("quoteVolume") val quoteVolume: String?,
    @SerializedName("count") val tradeCount: Long?
)
