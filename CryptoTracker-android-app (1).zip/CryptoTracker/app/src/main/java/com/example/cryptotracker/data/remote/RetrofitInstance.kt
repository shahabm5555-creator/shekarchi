package com.example.cryptotracker.data.remote

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Simple singleton Retrofit provider (manual DI — swap for Hilt/Koin in a
 * larger app; kept explicit here so the whole data flow is easy to trace).
 */
object RetrofitInstance {

    private const val COINGECKO_BASE_URL = "https://api.coingecko.com/api/v3/"
    private const val BINANCE_BASE_URL = "https://api.binance.com/"

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    val coinGeckoApi: CoinGeckoApiService by lazy {
        Retrofit.Builder()
            .baseUrl(COINGECKO_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(CoinGeckoApiService::class.java)
    }

    val binanceApi: BinanceApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BINANCE_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(BinanceApiService::class.java)
    }

    // --- Swap-in point for a real listings API (e.g. CoinMarketCal) ---
    // val listingApi: ListingApiService by lazy {
    //     Retrofit.Builder()
    //         .baseUrl("https://developers.coinmarketcal.com/v1/")
    //         .client(okHttpClient)
    //         .addConverterFactory(GsonConverterFactory.create())
    //         .build()
    //         .create(ListingApiService::class.java)
    // }
}
