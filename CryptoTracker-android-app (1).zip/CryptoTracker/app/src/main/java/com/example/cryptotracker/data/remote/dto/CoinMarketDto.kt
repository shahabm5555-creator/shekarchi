package com.example.cryptotracker.data.remote.dto

import com.google.gson.annotations.SerializedName

/**
 * Maps to a single entry of CoinGecko's `/coins/markets` response.
 * Docs: https://docs.coingecko.com/reference/coins-markets
 *
 * NOTE: CoinGecko's free market endpoint does NOT return a ready-made
 * "24h volume change %" field. We fetch this as our baseline snapshot and
 * derive the surge % in the repository layer — see CoinRepositoryImpl
 * for the exact strategy and how to swap in a paid/real-time source.
 */
data class CoinMarketDto(
    @SerializedName("id") val id: String,
    @SerializedName("symbol") val symbol: String,
    @SerializedName("name") val name: String,
    @SerializedName("image") val image: String,
    @SerializedName("current_price") val currentPrice: Double?,
    @SerializedName("market_cap") val marketCap: Double?,
    @SerializedName("market_cap_rank") val marketCapRank: Int?,
    @SerializedName("total_volume") val totalVolume: Double?,
    @SerializedName("price_change_percentage_24h") val priceChangePercentage24h: Double?,
    @SerializedName("price_change_percentage_1h_in_currency")
    val priceChangePercentage1h: Double?,
    @SerializedName("last_updated") val lastUpdated: String?
)
