package com.example.cryptotracker.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.cryptotracker.di.ServiceLocator
import com.example.cryptotracker.ui.screens.listings.ListingsScreen
import com.example.cryptotracker.ui.screens.listings.ListingsViewModel
import com.example.cryptotracker.ui.screens.volumesurge.VolumeSurgeScreen
import com.example.cryptotracker.ui.screens.volumesurge.VolumeSurgeViewModel

@Composable
fun CryptoTrackerNavGraph(navController: NavHostController = rememberNavController()) {
    Scaffold(
        bottomBar = { CryptoBottomBar(navController) }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.VolumeSurge.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.VolumeSurge.route) {
                val viewModel = remember { VolumeSurgeViewModel(ServiceLocator.coinRepository) }
                VolumeSurgeScreen(viewModel = viewModel)
            }
            composable(Screen.UpcomingListings.route) {
                val viewModel = remember { ListingsViewModel(ServiceLocator.listingRepository) }
                ListingsScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
private fun CryptoBottomBar(navController: NavHostController) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    NavigationBar {
        bottomNavItems.forEach { item ->
            NavigationBarItem(
                selected = currentRoute == item.screen.route,
                onClick = {
                    navController.navigate(item.screen.route) {
                        popUpTo(navController.graph.findStartDestination().id) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label) }
            )
        }
    }
}
