package com.example.cryptotracker.data.remote.dto

import com.google.gson.annotations.SerializedName

/**
 * Maps to `/coins/{id}/market_chart`. Each field is a list of
 * [timestampMillis, value] pairs. We use `total_volumes` to compare the
 * most recent 24h volume against the prior 24h volume, which gives a real
 * "volume spike %" instead of an approximation.
 *
 * Docs: https://docs.coingecko.com/reference/coins-id-market-chart
 */
data class MarketChartDto(
    @SerializedName("prices") val prices: List<List<Double>>?,
    @SerializedName("market_caps") val marketCaps: List<List<Double>>?,
    @SerializedName("total_volumes") val totalVolumes: List<List<Double>>?
)
