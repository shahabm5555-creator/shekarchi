package com.example.cryptotracker.ui.theme

import androidx.compose.ui.graphics.Color

// Dark, "crypto app" palette
val BackgroundDark = Color(0xFF0B0E11)
val SurfaceDark = Color(0xFF161A1E)
val SurfaceVariantDark = Color(0xFF1E2329)
val OutlineDark = Color(0xFF2B3139)

val AccentGreen = Color(0xFF0ECB81)   // gains / positive
val AccentRed = Color(0xFFF6465D)     // losses / negative
val AccentGold = Color(0xFFF0B90B)    // brand accent (Binance-style gold)
val AccentBlue = Color(0xFF3B82F6)

val TextPrimary = Color(0xFFEAECEF)
val TextSecondary = Color(0xFF848E9C)
