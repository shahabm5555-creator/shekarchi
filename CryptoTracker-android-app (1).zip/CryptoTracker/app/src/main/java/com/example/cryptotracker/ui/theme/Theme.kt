package com.example.cryptotracker.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val CryptoDarkColorScheme = darkColorScheme(
    primary = AccentGold,
    onPrimary = BackgroundDark,
    secondary = AccentBlue,
    background = BackgroundDark,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondary,
    outline = OutlineDark,
    error = AccentRed
)

/**
 * App is intentionally always-dark to match modern crypto-app UI
 * conventions (Binance/Bybit/Coinbase all default to dark). Set
 * [forceDark] = false if you want to respect the system theme instead.
 */
@Composable
fun CryptoTrackerTheme(
    forceDark: Boolean = true,
    content: @Composable () -> Unit
) {
    val darkTheme = forceDark || isSystemInDarkTheme()
    val colorScheme = CryptoDarkColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
