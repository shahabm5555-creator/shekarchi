package com.example.cryptotracker.data.repository

import com.example.cryptotracker.data.model.VolumeSurgeCoin
import com.example.cryptotracker.data.remote.BinanceApiService
import com.example.cryptotracker.data.remote.CoinGeckoApiService
import com.example.cryptotracker.data.remote.dto.BinanceTicker24hrDto
import com.example.cryptotracker.data.remote.dto.CoinMarketDto
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlin.math.abs

interface CoinRepository {
    /**
     * Coins ranked #1-#[maxMarketCapRank] by market cap that are also
     * traded on Binance, ranked by how much their real Binance capital
     * volume (USDT traded) has grown over the last 24h vs. the prior 24h.
     *
     * @param maxMarketCapRank only consider coins within the top N by
     *        market cap (default 1000, per the "1 to 1000" requirement).
     * @param candidatePoolSize how many of the current-highest-Binance-
     *        volume matches to run the expensive historical check on
     *        (keeps the number of klines calls bounded — see notes below).
     * @param minSurgePercent only include coins whose Binance volume rose
     *        by at least this percent vs. the prior 24h window.
     */
    suspend fun getVolumeSurgeCoins(
        maxMarketCapRank: Int = 1000,
        candidatePoolSize: Int = 40,
        minSurgePercent: Double = 15.0
    ): Result<List<VolumeSurgeCoin>>
}

class CoinRepositoryImpl(
    private val coinGeckoApi: CoinGeckoApiService,
    private val binanceApi: BinanceApiService
) : CoinRepository {

    private companion object {
        const val COINGECKO_PAGE_SIZE = 250 // CoinGecko's max per_page
        const val QUOTE_ASSET = "USDT"
        const val QUOTE_VOLUME_INDEX = 7 // klines[i][7] = quote asset volume
    }

    override suspend fun getVolumeSurgeCoins(
        maxMarketCapRank: Int,
        candidatePoolSize: Int,
        minSurgePercent: Double
    ): Result<List<VolumeSurgeCoin>> = runCatching {
        // Step 1: top-N coins by MARKET CAP from CoinGecko (paged, since
        // the API caps each page at 250 results).
        val marketCapCoins = fetchTopMarketCapCoins(maxMarketCapRank)

        // Step 2: every symbol currently trading on Binance, with its
        // live 24h stats — ONE call covers all of Binance's pairs.
        val binanceTickers = binanceApi.getAll24hrTickers()
        val binanceBySymbol: Map<String, BinanceTicker24hrDto> =
            binanceTickers.associateBy { it.symbol }

        // Step 3: keep only coins that are BOTH in the top-N market-cap
        // list AND actually listed on Binance against USDT.
        val matched = marketCapCoins.mapNotNull { coin ->
            val binanceSymbol = coin.symbol.uppercase() + QUOTE_ASSET
            val ticker = binanceBySymbol[binanceSymbol] ?: return@mapNotNull null
            val quoteVolume = ticker.quoteVolume?.toDoubleOrNull() ?: return@mapNotNull null
            Triple(coin, ticker, quoteVolume)
        }

        // Step 4: rank by CURRENT Binance capital volume and only run the
        // historical (klines) comparison on the top slice. Doing this for
        // all ~1000 coins would mean ~1000 extra API calls per refresh —
        // fine on Binance's generous rate limits in principle, but slow
        // and wasteful for a mobile client. Narrowing to the biggest
        // current-volume names first, then checking which of THOSE grew
        // the fastest, gives the same "capital flowing in" signal with a
        // bounded number of calls. Raise candidatePoolSize if you move
        // this logic to a backend job instead of the client.
        val candidates = matched
            .sortedByDescending { (_, _, quoteVolume) -> quoteVolume }
            .take(candidatePoolSize)

        coroutineScope {
            candidates
                .map { (coin, ticker, currentQuoteVolume) ->
                    async {
                        Triple(coin, ticker, computeBinanceVolumeSurge(coin.symbol, currentQuoteVolume))
                    }
                }
                .map { it.await() }
                .mapNotNull { (coin, ticker, surgeResult) ->
                    val (surgePercent, last24hVolume) = surgeResult ?: return@mapNotNull null
                    if (surgePercent < minSurgePercent) return@mapNotNull null
                    Triple(coin, ticker, surgePercent to last24hVolume)
                }
                .sortedByDescending { (_, _, surge) -> surge.first }
                .mapIndexed { index, (coin, ticker, surge) ->
                    coin.toVolumeSurgeCoin(
                        rank = index + 1,
                        ticker = ticker,
                        surgePercent = surge.first,
                        binanceVolume24h = surge.second
                    )
                }
        }
    }

    /** Pages through CoinGecko's markets endpoint, sorted by market cap, up to [maxRank]. */
    private suspend fun fetchTopMarketCapCoins(maxRank: Int): List<CoinMarketDto> {
        val pages = (maxRank + COINGECKO_PAGE_SIZE - 1) / COINGECKO_PAGE_SIZE
        val result = mutableListOf<CoinMarketDto>()
        for (page in 1..pages) {
            val perPage = minOf(COINGECKO_PAGE_SIZE, maxRank - result.size)
            if (perPage <= 0) break
            result += coinGeckoApi.getCoinMarkets(
                order = "market_cap_desc",
                perPage = perPage,
                page = page
            )
        }
        return result
    }

    /**
     * Fetches 48 hourly candles for [coinSymbol]+USDT on Binance and
     * returns (surgePercent, last24hQuoteVolume), or null if the pair
     * isn't tradable / has insufficient history. A single flaky symbol
     * never fails the whole screen.
     */
    private suspend fun computeBinanceVolumeSurge(
        coinSymbol: String,
        fallbackCurrentVolume: Double
    ): Pair<Double, Double>? = runCatching {
        val symbol = coinSymbol.uppercase() + QUOTE_ASSET
        val klines = binanceApi.getKlines(symbol = symbol, interval = "1h", limit = 48)
        if (klines.size < 48) return@runCatching null

        val quoteVolumes = klines.map { candle ->
            (candle.getOrNull(QUOTE_VOLUME_INDEX) as? String)?.toDoubleOrNull()
                ?: (candle.getOrNull(QUOTE_VOLUME_INDEX) as? Double)
                ?: 0.0
        }

        val last24h = quoteVolumes.takeLast(24).sum()
        val prev24h = quoteVolumes.takeLast(48).take(24).sum()
        if (prev24h <= 0.0) return@runCatching null

        val surgePercent = ((last24h - prev24h) / prev24h) * 100.0
        surgePercent to last24h
    }.getOrNull()

    private fun CoinMarketDto.toVolumeSurgeCoin(
        rank: Int,
        ticker: BinanceTicker24hrDto,
        surgePercent: Double,
        binanceVolume24h: Double
    ) = VolumeSurgeCoin(
        rank = rank,
        marketCapRank = marketCapRank ?: 0,
        id = id,
        name = name,
        symbol = symbol.uppercase(),
        iconUrl = image,
        currentPrice = ticker.lastPrice?.toDoubleOrNull() ?: currentPrice ?: 0.0,
        priceChangePercent24h = ticker.priceChangePercent?.toDoubleOrNull()
            ?: priceChangePercentage24h ?: 0.0,
        volumeChangePercent24h = surgePercent,
        totalVolume24h = binanceVolume24h,
        marketCap = marketCap ?: 0.0
    )
}

/** Small helper kept here so the UI layer never needs to know the sign convention. */
fun Double.isPositiveSurge(): Boolean = this >= 0.0
fun Double.absValue(): Double = abs(this)
