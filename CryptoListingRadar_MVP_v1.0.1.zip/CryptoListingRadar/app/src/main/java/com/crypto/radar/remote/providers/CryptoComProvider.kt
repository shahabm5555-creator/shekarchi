package com.crypto.radar.remote.providers

/** Provider adapter placeholder for CryptoCom. */
class CryptoComProvider
