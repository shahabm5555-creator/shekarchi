package com.crypto.radar.model

data class ListingAlert(
    val id: Long = 0,
    val coin: String,
    val exchange: String,
    val confidence: Int,
    val status: String,
    val sourceText: String = "",
    val detectedAt: Long = System.currentTimeMillis()
)

data class Coin(val symbol: String, val name: String)
