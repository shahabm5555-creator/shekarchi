package com.crypto.radar.remote.providers

/** Provider adapter placeholder for Coinbase. */
class CoinbaseProvider
