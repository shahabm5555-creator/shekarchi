package com.crypto.radar.remote.providers

/** Provider adapter placeholder for OKX. */
class OKXProvider
