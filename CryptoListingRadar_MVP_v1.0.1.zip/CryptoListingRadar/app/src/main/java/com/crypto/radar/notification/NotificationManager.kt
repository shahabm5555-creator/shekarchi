package com.crypto.radar.notification

import android.app.NotificationChannel
import android.app.NotificationManager as AndroidNotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import com.crypto.radar.R
import com.crypto.radar.model.ListingAlert

object NotificationManager {
    private const val CHANNEL_ID = "listing_alerts"

    fun createChannel(context: Context) {
        val channel = NotificationChannel(
            CHANNEL_ID, "Crypto Listing Alerts",
            AndroidNotificationManager.IMPORTANCE_HIGH
        )
        context.getSystemService(AndroidNotificationManager::class.java).createNotificationChannel(channel)
    }

    fun notify(context: Context, alert: ListingAlert) {
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("🚀 New Listing Alert")
            .setContentText("${alert.coin} • ${alert.exchange} • ${alert.confidence}%")
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "Coin: ${alert.coin}\nExchange: ${alert.exchange}\nConfidence: ${alert.confidence}%"
            ))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        context.getSystemService(AndroidNotificationManager::class.java)
            .notify(alert.id.toInt().coerceAtLeast(1), notification)
    }
}
