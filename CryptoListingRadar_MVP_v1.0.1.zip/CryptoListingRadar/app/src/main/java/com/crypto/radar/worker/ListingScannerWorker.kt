package com.crypto.radar.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.crypto.radar.ai.ListingAnalyzer
import com.crypto.radar.notification.NotificationManager

class ListingScannerWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        // Replace this demo feed with real exchange announcement providers.
        val sample = "Binance will list XYZ for spot trading. Trading starts tomorrow."
        val alert = ListingAnalyzer().analyze(sample, "Binance")
        if (alert != null && alert.confidence >= 80) {
            NotificationManager.notify(applicationContext, alert.copy(id = System.currentTimeMillis()))
        }
        return Result.success()
    }
}
