package com.crypto.radar.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alerts")
data class AlertEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val coin: String,
    val exchange: String,
    val confidence: Int,
    val status: String,
    val sourceText: String,
    val detectedAt: Long
)

@Database(entities = [AlertEntity::class], version = 1, exportSchema = false)
abstract class CryptoDatabase : RoomDatabase()
