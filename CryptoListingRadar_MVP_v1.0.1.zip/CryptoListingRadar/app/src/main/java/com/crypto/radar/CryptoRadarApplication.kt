package com.crypto.radar

import android.app.Application
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.crypto.radar.notification.NotificationManager
import com.crypto.radar.worker.ListingScannerWorker
import java.util.concurrent.TimeUnit

class CryptoRadarApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationManager.createChannel(this)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "listing-scanner",
            ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<ListingScannerWorker>(30, TimeUnit.MINUTES).build()
        )
    }
}
