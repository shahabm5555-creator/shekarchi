package com.crypto.radar.remote.providers

/** Provider adapter placeholder for Kraken. */
class KrakenProvider
