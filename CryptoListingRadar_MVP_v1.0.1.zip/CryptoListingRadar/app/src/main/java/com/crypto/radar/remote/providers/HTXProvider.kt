package com.crypto.radar.remote.providers

/** Provider adapter placeholder for HTX. */
class HTXProvider
