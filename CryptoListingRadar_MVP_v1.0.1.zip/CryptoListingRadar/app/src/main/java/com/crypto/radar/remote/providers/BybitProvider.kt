package com.crypto.radar.remote.providers

/** Provider adapter placeholder for Bybit. */
class BybitProvider
