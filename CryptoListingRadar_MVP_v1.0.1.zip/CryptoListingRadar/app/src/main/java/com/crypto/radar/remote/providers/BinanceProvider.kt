package com.crypto.radar.remote.providers

/** Provider adapter placeholder for Binance. */
class BinanceProvider
