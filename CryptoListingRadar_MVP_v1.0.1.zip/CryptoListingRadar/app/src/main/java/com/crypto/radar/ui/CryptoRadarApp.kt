package com.crypto.radar.ui

import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import com.crypto.radar.navigation.CryptoNavGraph

@Composable
fun CryptoRadarApp() {
    Scaffold { CryptoNavGraph() }
}
