package com.crypto.radar.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.crypto.radar.ui.screens.*

@Composable
fun CryptoNavGraph() {
    val nav = rememberNavController()
    NavHost(nav, startDestination = "dashboard") {
        composable("dashboard") { DashboardScreen() }
        composable("alerts") { AlertsScreen() }
        composable("watchlist") { WatchlistScreen() }
        composable("history") { HistoryScreen() }
        composable("settings") { SettingsScreen() }
    }
}
