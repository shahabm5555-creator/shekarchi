package com.crypto.radar.remote

import retrofit2.http.GET

interface CryptoApiService {
    // Provider-specific endpoints can be added here.
    @GET(".")
    suspend fun health(): String
}
