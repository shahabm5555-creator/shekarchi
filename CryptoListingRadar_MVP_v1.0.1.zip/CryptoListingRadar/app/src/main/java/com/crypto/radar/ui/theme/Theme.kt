package com.crypto.radar.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Scheme = darkColorScheme(
    primary = Color(0xFF00FF88),
    secondary = Color(0xFF008CFF),
    background = Color(0xFF050505),
    surface = Color(0xFF101318)
)

@Composable
fun CryptoRadarTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
