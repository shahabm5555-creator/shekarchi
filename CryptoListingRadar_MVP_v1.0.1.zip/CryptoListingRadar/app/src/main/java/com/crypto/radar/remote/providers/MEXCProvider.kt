package com.crypto.radar.remote.providers

/** Provider adapter placeholder for MEXC. */
class MEXCProvider
