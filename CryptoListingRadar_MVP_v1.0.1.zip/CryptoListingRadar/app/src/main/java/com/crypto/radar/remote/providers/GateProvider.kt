package com.crypto.radar.remote.providers

/** Provider adapter placeholder for Gate. */
class GateProvider
