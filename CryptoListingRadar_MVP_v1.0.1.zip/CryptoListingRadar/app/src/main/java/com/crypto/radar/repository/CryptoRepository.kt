package com.crypto.radar.repository

import com.crypto.radar.ai.ListingAnalyzer
import com.crypto.radar.model.ListingAlert

class CryptoRepository(private val analyzer: ListingAnalyzer = ListingAnalyzer()) {
    fun analyze(text: String, exchange: String): ListingAlert? =
        analyzer.analyze(text, exchange)
}
