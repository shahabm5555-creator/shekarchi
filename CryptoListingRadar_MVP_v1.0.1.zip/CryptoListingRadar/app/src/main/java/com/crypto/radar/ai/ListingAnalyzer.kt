package com.crypto.radar.ai

import com.crypto.radar.model.ListingAlert

class ListingAnalyzer {
    private val strong = listOf("will list", "listing announcement", "spot listing", "trading starts")
    private val medium = listOf("new token listing", "available for trading", "supporting")

    fun analyze(text: String, exchange: String): ListingAlert? {
        val normalized = text.lowercase()
        val matched = strong.count { normalized.contains(it) }
        val mediumMatched = medium.count { normalized.contains(it) }
        if (matched == 0 && mediumMatched == 0) return null

        val confidence = (matched * 25 + mediumMatched * 15 + if (exchange.isNotBlank()) 10 else 0)
            .coerceIn(0, 100)

        val coin = Regex("""\b[A-Z][A-Z0-9]{1,9}\b""")
            .find(text)?.value ?: "UNKNOWN"

        return ListingAlert(
            coin = coin,
            exchange = exchange,
            confidence = confidence,
            status = if (confidence >= 80) "CONFIRMED" else "DETECTED",
            sourceText = text
        )
    }
}
