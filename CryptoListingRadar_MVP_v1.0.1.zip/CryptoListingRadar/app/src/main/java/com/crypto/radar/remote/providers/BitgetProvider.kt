package com.crypto.radar.remote.providers

/** Provider adapter placeholder for Bitget. */
class BitgetProvider
