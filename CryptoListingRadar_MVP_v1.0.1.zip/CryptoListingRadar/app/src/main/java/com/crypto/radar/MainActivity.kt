package com.crypto.radar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.crypto.radar.ui.CryptoRadarApp
import com.crypto.radar.ui.theme.CryptoRadarTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CryptoRadarTheme { CryptoRadarApp() } }
    }
}
