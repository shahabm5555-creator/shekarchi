package com.crypto.radar.remote.providers

/** Provider adapter placeholder for KuCoin. */
class KuCoinProvider
