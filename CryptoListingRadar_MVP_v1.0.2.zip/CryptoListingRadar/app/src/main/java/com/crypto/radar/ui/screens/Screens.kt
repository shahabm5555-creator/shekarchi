package com.crypto.radar.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
private fun Base(title: String, body: @Composable ColumnScope.() -> Unit) {
    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.padding(20.dp).fillMaxSize()
        ) {
            Text(title, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(20.dp))
            body()
        }
    }
}

@Composable fun DashboardScreen() = Base("🚀 Crypto Listing Radar") {
    Text("Latest Detection", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(12.dp))
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("XYZ  •  Binance", style = MaterialTheme.typography.titleLarge)
            Text("Confidence 95%", color = MaterialTheme.colorScheme.primary)
            Text("Status: Confirmed")
        }
    }
    Spacer(Modifier.height(24.dp))
    Text("Supported Exchanges")
    Text("Binance • Coinbase • OKX • Bybit • Kraken • KuCoin • Gate.io")
    Text("Bitget • MEXC • Crypto.com • HTX")
}
@Composable fun AlertsScreen() = Base("🚨 Alerts") { Text("Listing alerts will appear here.") }
@Composable fun WatchlistScreen() = Base("⭐ Watchlist") { Text("Add coins you want to monitor.") }
@Composable fun HistoryScreen() = Base("📜 History") { Text("Detected listing history.") }
@Composable fun SettingsScreen() = Base("⚙ Settings") {
    Text("Notifications: Enabled")
    Text("Confidence threshold: 80%")
    Text("Scanner interval: 30 minutes")
}
