# Crypto Tracker (Volume Surge + Upcoming Listings)

A Kotlin + Jetpack Compose Android app with two screens:

1. **Volume Surge** — top coins by 24h trading-volume increase (real data, CoinGecko).
2. **Upcoming Listings** — upcoming CEX listing announcements (mocked, ready to swap for a real feed — see below).

Dark Material 3 UI, bottom navigation, MVVM + light Clean Architecture (data / domain-ish repository layer / ui), Retrofit + Gson, Coroutines + Flow, Coil for images.

---

## 1. Project structure

```
CryptoTracker/
├── build.gradle.kts                 # root build script
├── settings.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── app/
│   ├── build.gradle.kts             # app module deps (Compose, Retrofit, Coil, Nav...)
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── res/
│       │   ├── values/strings.xml, themes.xml, ic_launcher_background.xml
│       │   ├── drawable/ic_launcher_foreground.xml
│       │   └── mipmap-anydpi-v26/ic_launcher.xml, ic_launcher_round.xml
│       └── java/com/example/cryptotracker/
│           ├── MainActivity.kt
│           ├── di/ServiceLocator.kt                 # manual DI (swap for Hilt if desired)
│           ├── data/
│           │   ├── model/
│           │   │   ├── Coin.kt                      # VolumeSurgeCoin (UI-facing model)
│           │   │   └── Listing.kt                   # Listing + ListingStatus
│           │   ├── remote/
│           │   │   ├── CoinGeckoApiService.kt        # Retrofit interface (markets + chart)
│           │   │   ├── RetrofitInstance.kt           # Retrofit/OkHttp singleton
│           │   │   └── dto/
│           │   │       ├── CoinMarketDto.kt
│           │   │       └── MarketChartDto.kt
│           │   └── repository/
│           │       ├── CoinRepository.kt             # real volume-surge calculation
│           │       └── ListingRepository.kt          # mock + real-API swap notes
│           └── ui/
│               ├── theme/Color.kt, Type.kt, Theme.kt
│               ├── navigation/BottomNavItem.kt, NavGraph.kt
│               ├── components/
│               │   ├── VolumeSurgeCoinItem.kt
│               │   ├── ListingItem.kt
│               │   └── StateComposables.kt           # loading/error states
│               └── screens/
│                   ├── volumesurge/VolumeSurgeScreen.kt, VolumeSurgeViewModel.kt
│                   └── listings/ListingsScreen.kt, ListingsViewModel.kt
```

---

## 2. Dependencies (already wired in `app/build.gradle.kts`)

- Jetpack Compose BOM `2024.06.00`, Material 3, Material Icons Extended
- `androidx.navigation:navigation-compose:2.7.7`
- `retrofit2` + `converter-gson` + `okhttp` (+ logging interceptor)
- `kotlinx-coroutines-android`
- `io.coil-kt:coil-compose` for image loading
- Lifecycle ViewModel Compose

No API keys are required to run the app out of the box (CoinGecko's public endpoints are key-less; listings are mocked locally).

---

## 3. How the two screens get their data

### Screen 1 — Volume Surge (real API: CoinGecko, no key needed)
- `CoinGeckoApiService.getCoinMarkets()` → `GET /coins/markets?order=volume_desc` for the current top-volume snapshot.
- CoinGecko's free market endpoint does **not** return a ready-made "24h volume change %" field, so `CoinRepositoryImpl.computeVolumeSurge()` calls `GET /coins/{id}/market_chart?days=2&interval=hourly` per coin and compares **last 24h summed volume** vs **previous 24h summed volume** to compute a real surge percentage. Coins below `minSurgePercent` (default 20%) are filtered out and the rest are ranked by surge %.
- This is intentionally simple and transparent for a demo; see section 4 for production alternatives.

### Screen 2 — Upcoming Listings (currently mocked, real-API-ready)
There is no single free, key-less public API that tracks "upcoming CEX listing announcements" the way CoinGecko covers market data. `MockListingRepositoryImpl` (in `ListingRepository.kt`) ships 6 realistic sample entries so the screen is fully functional immediately. The `ListingRepository` interface and `ListingsViewModel` don't know or care whether the data is mocked or real — see section 4 for how to plug in a real source.

---

## 4. Connecting real-world data sources

### Volume Surge — going beyond the demo calculation
The included per-coin `market_chart` loop works but does `topN` extra network calls, which will hit CoinGecko's free-tier rate limit (~10-30 req/min) once you raise `topN` much above ~25-30. For production:

- **CoinGecko Pro** — paid plans return more fields per call and higher rate limits; you can also use their `/coins/markets` with a wider `price_change_percentage` window, or their dedicated trending/gainers-losers endpoints.
- **CoinMarketCap Pro API** — the `/v1/cryptocurrency/listings/latest` endpoint returns a `volume_change_24h` field directly (no per-coin loop needed). Requires an API key (`CMC_PRO_API_KEY` header).
- **Binance/Bybit public REST APIs** — `GET /api/v3/ticker/24hr` (Binance) gives per-symbol 24h volume; you'd snapshot it on your own backend every N hours to compute deltas yourself, which avoids third-party rate limits entirely and lets you tune the surge window.
- **Self-hosted approach (recommended at scale)**: run a small cron job/server that polls your chosen exchange or aggregator hourly, stores volume snapshots (e.g. in Firestore/Postgres), and exposes a single `/volume-surge` endpoint your app calls — this removes all per-coin fan-out from the client entirely.

To swap the implementation, only `CoinRepositoryImpl` needs to change — `CoinRepository` (the interface), `VolumeSurgeViewModel`, and the UI are untouched since they depend on the interface, not the concrete class.

### Upcoming Listings — going from mock to real
1. **CoinMarketCal API** (https://coinmarketcal.com/en/apidoc) — free tier available, has an `exchange-listing` event category. Sign up for an API key, add a `ListingApiService` Retrofit interface (a stub is sketched at the bottom of `ListingRepository.kt`), and add the key via `RetrofitInstance` or a `local.properties`-backed `BuildConfig` field (don't hardcode it).
2. **Exchange announcement feeds** — Binance, Coinbase, KuCoin, and Bybit all publish RSS/JSON feeds for their announcement sections. You can build a lightweight backend (Cloud Function, etc.) that polls these, tags posts mentioning "will list" / "New Listing", and exposes a normalized JSON endpoint for the app to consume — this avoids scraping HTML on-device and lets you keep a stable schema.
3. Once you have a real source, implement `RemoteListingRepositoryImpl : ListingRepository` and swap it in `ServiceLocator.kt`:
   ```kotlin
   val listingRepository: ListingRepository by lazy {
       RemoteListingRepositoryImpl(api = RetrofitInstance.listingApi, apiKey = BuildConfig.LISTING_API_KEY)
   }
   ```
   No other file needs to change.

---

## 5. Running the project

1. Open the `CryptoTracker/` folder in **Android Studio (Koala/2024.1+)**.
2. Let Android Studio sync Gradle — it will generate the Gradle wrapper JAR automatically on first sync (this project ships `gradle/wrapper/gradle-wrapper.properties` pointing at Gradle 8.7, but not the binary `gradle-wrapper.jar`, since that's a binary file; Android Studio creates it for you, or run `gradle wrapper` once if you have Gradle installed locally).
3. Run on an emulator or device with **API 24+**.
4. Internet permission is already declared; no configuration needed for the mocked/free endpoints.

---

## 6. Notes / possible next steps
- Add a Room cache layer so both screens survive offline/cold-start gracefully.
- Add pull-to-refresh (`androidx.compose.material.pullrefresh` or Accompanist SwipeRefresh) on both `LazyColumn`s — the ViewModels already expose `onRefresh()`.
- Move `ServiceLocator` to Hilt (`@HiltAndroidApp`, `@Inject` constructors) once the project grows past a couple of screens.
- Add unit tests for `CoinRepositoryImpl.computeVolumeSurge()` math and `ListingsViewModel` state transitions.
