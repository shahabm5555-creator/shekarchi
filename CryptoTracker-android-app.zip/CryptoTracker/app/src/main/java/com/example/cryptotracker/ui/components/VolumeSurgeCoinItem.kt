package com.example.cryptotracker.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.cryptotracker.data.model.VolumeSurgeCoin
import com.example.cryptotracker.ui.theme.AccentGreen
import com.example.cryptotracker.ui.theme.AccentRed
import com.example.cryptotracker.ui.theme.TextSecondary
import java.text.NumberFormat
import java.util.Locale

@Composable
fun VolumeSurgeCoinItem(
    coin: VolumeSurgeCoin,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = coin.rank.toString(),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                modifier = Modifier.width(24.dp)
            )

            AsyncImage(
                model = coin.iconUrl,
                contentDescription = "${coin.name} icon",
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = coin.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.width(4.dp))
                Row {
                    Text(
                        text = coin.symbol,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Vol ${formatCompactUsd(coin.totalVolume24h)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = formatPrice(coin.currentPrice),
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.width(4.dp))
                SurgeBadge(percent = coin.volumeChangePercent24h)
            }
        }
    }
}

@Composable
private fun SurgeBadge(percent: Double) {
    val isPositive = percent >= 0
    val color = if (isPositive) AccentGreen else AccentRed

    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (isPositive) Icons.Filled.ArrowUpward else Icons.Filled.ArrowDownward,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(12.dp)
        )
        Text(
            text = String.format(Locale.US, "%.1f%%", kotlin.math.abs(percent)),
            style = MaterialTheme.typography.labelSmall,
            color = color
        )
    }
}

private fun formatPrice(price: Double): String {
    val formatter = NumberFormat.getCurrencyInstance(Locale.US)
    formatter.maximumFractionDigits = if (price < 1) 6 else 2
    return formatter.format(price)
}

private fun formatCompactUsd(value: Double): String = when {
    value >= 1_000_000_000 -> String.format(Locale.US, "$%.2fB", value / 1_000_000_000)
    value >= 1_000_000 -> String.format(Locale.US, "$%.2fM", value / 1_000_000)
    value >= 1_000 -> String.format(Locale.US, "$%.1fK", value / 1_000)
    else -> String.format(Locale.US, "$%.0f", value)
}
