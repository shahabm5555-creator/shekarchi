package com.example.cryptotracker.ui.screens.volumesurge

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.cryptotracker.ui.components.FullScreenError
import com.example.cryptotracker.ui.components.FullScreenLoading
import com.example.cryptotracker.ui.components.VolumeSurgeCoinItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolumeSurgeScreen(viewModel: VolumeSurgeViewModel) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Volume Surge", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            when {
                uiState.isLoading && uiState.coins.isEmpty() -> FullScreenLoading()

                uiState.errorMessage != null && uiState.coins.isEmpty() -> FullScreenError(
                    message = uiState.errorMessage
                        ?: "Something went wrong. Pull to retry.",
                    onRetry = viewModel::onRefresh
                )

                else -> VolumeSurgeList(
                    coins = uiState.coins,
                    subtitle = "Coins with the biggest 24h trading-volume increase, " +
                        "compared to the prior 24h window."
                )
            }
        }
    }
}

@Composable
private fun VolumeSurgeList(
    coins: List<com.example.cryptotracker.data.model.VolumeSurgeCoin>,
    subtitle: String
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        items(items = coins, key = { it.id }) { coin ->
            VolumeSurgeCoinItem(coin = coin)
        }

        if (coins.isEmpty()) {
            item {
                Text(
                    text = "No coins currently show a significant volume spike.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 24.dp)
                )
            }
        }
    }
}
