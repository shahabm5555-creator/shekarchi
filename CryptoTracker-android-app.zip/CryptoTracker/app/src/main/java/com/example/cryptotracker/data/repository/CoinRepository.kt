package com.example.cryptotracker.data.repository

import com.example.cryptotracker.data.model.VolumeSurgeCoin
import com.example.cryptotracker.data.remote.CoinGeckoApiService
import com.example.cryptotracker.data.remote.dto.CoinMarketDto
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlin.math.abs

interface CoinRepository {
    /**
     * Returns coins ranked by 24h volume-change %, highest surge first.
     * @param topN how many of the highest-volume coins to analyze (keeps
     *             API calls bounded — see implementation notes below).
     * @param minSurgePercent only include coins whose volume rose by at
     *             least this percent vs. the prior 24h window.
     */
    suspend fun getVolumeSurgeCoins(
        topN: Int = 30,
        minSurgePercent: Double = 20.0
    ): Result<List<VolumeSurgeCoin>>
}

class CoinRepositoryImpl(
    private val api: CoinGeckoApiService
) : CoinRepository {

    override suspend fun getVolumeSurgeCoins(
        topN: Int,
        minSurgePercent: Double
    ): Result<List<VolumeSurgeCoin>> = runCatching {
        // Step 1: pull the current top-volume snapshot (1 call).
        val markets = api.getCoinMarkets(perPage = topN, page = 1)

        // Step 2: for each coin, pull 48h of hourly volume history and
        // compare "last 24h" vs "previous 24h" to get a REAL surge %.
        // This is N extra calls — on CoinGecko's free tier that's fine for
        // ~20-30 coins but will hit rate limits at higher topN. For
        // production, replace this per-coin loop with a single call to a
        // provider that returns volume-change-% directly (CoinGecko Pro's
        // `/coins/markets` on paid plans, CoinMarketCap's `volume_change_24h`
        // field, or a self-hosted job that snapshots volumes hourly into
        // your own database).
        coroutineScope {
            val deferred = markets.map { dto ->
                async { dto to computeVolumeSurge(dto) }
            }
            deferred
                .map { it.await() }
                .mapNotNull { (dto, surgePercent) ->
                    if (surgePercent == null || surgePercent < minSurgePercent) {
                        null
                    } else {
                        dto to surgePercent
                    }
                }
                .sortedByDescending { it.second }
                .mapIndexed { index, (dto, surgePercent) ->
                    dto.toVolumeSurgeCoin(rank = index + 1, surgePercent = surgePercent)
                }
        }
    }

    /**
     * Fetches hourly volume history for a single coin and returns the %
     * change of the most recent 24h volume vs. the previous 24h volume.
     * Returns null if history is insufficient or the call fails (so a
     * single flaky coin doesn't fail the whole screen).
     */
    private suspend fun computeVolumeSurge(dto: CoinMarketDto): Double? = runCatching {
        val chart = api.getMarketChart(coinId = dto.id, days = 2, interval = "hourly")
        val volumes = chart.totalVolumes.orEmpty().map { it.getOrElse(1) { 0.0 } }
        if (volumes.size < 48) return@runCatching null

        val last24h = volumes.takeLast(24).sum()
        val prev24h = volumes.takeLast(48).take(24).sum()
        if (prev24h <= 0.0) return@runCatching null

        ((last24h - prev24h) / prev24h) * 100.0
    }.getOrNull()

    private fun CoinMarketDto.toVolumeSurgeCoin(rank: Int, surgePercent: Double) =
        VolumeSurgeCoin(
            rank = rank,
            id = id,
            name = name,
            symbol = symbol.uppercase(),
            iconUrl = image,
            currentPrice = currentPrice ?: 0.0,
            priceChangePercent24h = priceChangePercentage24h ?: 0.0,
            volumeChangePercent24h = surgePercent,
            totalVolume24h = totalVolume ?: 0.0,
            marketCap = marketCap ?: 0.0
        )
}

/** Small helper kept here so the UI layer never needs to know the sign convention. */
fun Double.isPositiveSurge(): Boolean = this >= 0.0
fun Double.absValue(): Double = abs(this)
