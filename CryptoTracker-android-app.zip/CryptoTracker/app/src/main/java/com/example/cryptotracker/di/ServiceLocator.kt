package com.example.cryptotracker.di

import com.example.cryptotracker.data.remote.RetrofitInstance
import com.example.cryptotracker.data.repository.CoinRepository
import com.example.cryptotracker.data.repository.CoinRepositoryImpl
import com.example.cryptotracker.data.repository.ListingRepository
import com.example.cryptotracker.data.repository.MockListingRepositoryImpl

/**
 * Minimal hand-rolled DI container. For a larger codebase, replace this
 * with Hilt (@HiltAndroidApp / @Inject) — kept manual here so the whole
 * wiring is visible in one file without extra annotation-processing setup.
 */
object ServiceLocator {

    val coinRepository: CoinRepository by lazy {
        CoinRepositoryImpl(api = RetrofitInstance.coinGeckoApi)
    }

    val listingRepository: ListingRepository by lazy {
        // Swap for RemoteListingRepositoryImpl(...) once you have a
        // listings API key — see ListingRepository.kt for details.
        MockListingRepositoryImpl()
    }
}
